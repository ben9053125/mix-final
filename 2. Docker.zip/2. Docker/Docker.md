# Dockerfile

> I have provided a public docker image. < m10913018/nltk_env:2.3.0 > \
> There are only python packages and html files inside, no code related to natural language processing.

<img src="https://github.com/WEICHINLIN/Kubeflow---Natural-Language-Processing/blob/main/4.%20Image/NLP.png" alt="NLP"/><br/>

> The font may be displayed differently due to environmental issues, but it does not affect the function. \
> You can customize the web page and remake the docker image.

# Relevant part

* [About Version](https://github.com/WEICHINLIN/Kubeflow---Natural-Language-Processing/blob/main/README.md)
* [About Install](https://github.com/WEICHINLIN/Kubeflow---Natural-Language-Processing/blob/main/1.%20Install/Install.md)
* [About Jupyter Notebook](https://github.com/WEICHINLIN/Kubeflow---Natural-Language-Processing/blob/main/3.%20Jupyter%20Notebook/Jupyter%20Notebook.md)
